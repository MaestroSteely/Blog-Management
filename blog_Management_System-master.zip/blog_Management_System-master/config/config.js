const sessionSecret = "blogsessionusersecret";

module.exports = { sessionSecret };